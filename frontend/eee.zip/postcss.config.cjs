// ecommerce_bd/frontend/postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}, // Autoprefixer es bueno tenerlo también
  },
};